package edu.neu.coe.info6205.union_find;

public class UFException extends Exception {
    public UFException(String msg) {
        super(msg);
    }
}
